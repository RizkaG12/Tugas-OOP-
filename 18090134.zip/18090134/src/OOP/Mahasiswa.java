
package OOP;

public class Mahasiswa {
     public static void main(String[] args) {
      String nama = "RIZKA NADIA AHMI FASYACH";
      String kelas = "4C";
      String nim = "18090134";
        System.out.println("Nama : "+nama);
        System.out.println("Kelas : "+kelas);
        System.out.println("Nim : "+nim);
        
    }
}
